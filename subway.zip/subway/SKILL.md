---
name: subway
description: "Generate, serve, and explore Subway codebase maps using the Subway MCP tools. This skill should be used when the user asks to map a codebase, generate a subway.json, create a subway map, visualize project structure, or serve a subway viewer."
---

# Subway — Codebase Mapping and Serving

## Overview

Use the Subway MCP server to build interactive visual maps of any codebase,
then generate and serve a self-contained HTML viewer. The MCP server provides
23 tools — 9 read tools for exploring existing maps and 14 build tools for
creating new ones from scratch.

## Critical Rule: Environment Detection & File Filtering

### Step 0: Detect the Environment

**Before generating `subway.json`, you MUST first understand what you're mapping.**
Read the project root (`subway_read_dir` or `ls`), check for framework markers,
and classify the project into one of these environments:

| Environment | Markers | Focus On | Ignore |
|---|---|---|---|
| **Generic / Desktop** | `package.json`+`electron`, `Cargo.toml`, `CMakeLists.txt`, `main.py`, Wails/Tauri config | Application entry points, core logic, UI modules | Framework internals, build tool configs, platform shims |
| **iOS** | `.xcodeproj`, `.xcworkspace`, `Podfile`, `*.swift` with `@main`/`UIApplicationDelegate` | SwiftUI Views, UIKit ViewControllers, AppDelegate, SceneDelegate | Storyboards (unless custom), `.xcodeproj` internals, `Pods/`, `DerivedData/` |
| **Android** | `build.gradle*`, `AndroidManifest.xml`, `*.kt` with `@Composable` | Jetpack Compose screens, Activities, ViewModels, Fragments | `build/`, `.gradle/`, generated `R.java`/`BuildConfig`, resource XML configs |
| **Web** | `next.config.*`, `vite.config.*`, `svelte.config.*`, `index.html`+SPA router, `wrangler.toml` | Pages, components, API routes, layouts, state stores | `dist/`, `.next/`, `out/`, `public/assets/`, static bundled output |
| **React Native / Expo** | `app.json`/`app.config.*`, `metro.config.*`, `eas.json` | Screens, components, navigation config, services | `android/` (native wrappers), `ios/` (native wrappers), `.expo/`, `node_modules/` |
| **Flutter** | `pubspec.yaml`, `lib/main.dart`, `android/`+`ios/` under project root | `lib/` Dart source, screens, widgets, blocs/cubits, models | `android/` Java/Kotlin wrappers, `ios/` Swift wrappers, `.dart_tool/`, `build/`, `*.g.dart`, `*.freezed.dart` |
| **Other / Unknown** | None of the above | All hand-written source files | All dot-files, build artifacts, generated code, dependencies |

### Step 0b: Universal Exclusions (Always Apply)

These are excluded regardless of environment:

| Category | Examples |
|---|---|
| **Dot-files** (start with `.`) | `.gitignore`, `.env`, `.eslintrc*`, `.prettierrc*`, `.editorconfig`, `.babelrc`, `.npmrc`, `.nvmrc`, `.rubocop.yml` |
| **System files** | `.DS_Store`, `Thumbs.db`, `desktop.ini` |
| **Package dependencies** | `node_modules/`, `vendor/`, `packages/`, `.venv/`, `venv/`, `Pods/` |
| **Build artifacts** | `dist/`, `build/`, `target/`, `.next/`, `out/`, `DerivedData/` |
| **Cache directories** | `__pycache__/`, `.cache/`, `.turbo/`, `.parcel-cache/`, `.tsbuildinfo`, `.dart_tool/`, `.gradle/` |
| **Generated code** | `*.generated.*`, `*.g.dart`, `*.pb.go`, `*.pb.cc`, auto-generated GraphQL types, gRPC stubs, `R.java`, `BuildConfig.java` |
| **IDE / editor config** | `.vscode/`, `.idea/`, `.project`, `.classpath`, `*.sublime-*`, `.xcodeproj/`, `.xcworkspace/` (top-level config only, not source) |
| **Lock files** | `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `Gemfile.lock`, `composer.lock`, `Cargo.lock`, `poetry.lock`, `Podfile.lock` |
| **Framework intrinsic files** | Storyboards (iOS), `AndroidManifest.xml` (structure-only), `*.plist` configs (unless project-specific), `gradlew*` scripts, `metro.config.js`, `babel.config.js` |
| **Test fixtures / mocks** | Large binary fixtures, snapshots not owned by the project, `*.snap` (except deliberate snapshot tests) |
| **Standard library internals** | Any file under system paths (`/usr/lib/`, `/Library/`, `GOPATH/src/`), vendored SDK headers |

Apply this filter at every step: when exploring directories, when selecting files for stations, and when reviewing the final `subway.json`. If in doubt whether a file is project-specific source code, exclude it.

## Prerequisites and Setup

### Check if Subway is installed

Subway MCP tools are provided by the `@municode/subway` npm package.
Before using any tool, verify it's available:

```bash
which subway-mcp || npm list -g @municode/subway 2>/dev/null
```

### Install (if needed)

If `subway-mcp` is not found, install globally:

```bash
npm install -g @municode/subway@latest
```

Or use without installing via `npx`:

```bash
npx @municode/subway subway-mcp
```

### Configure the MCP server

For the MCP tools to be callable within this session, the Subway MCP server
must be registered as an MCP provider. Common configurations:

**Claude Desktop** (`~/.config/claude/claude_desktop_config.json` or
`~/Library/Application Support/Claude/claude_desktop_config.json`):
```json
{
  "mcpServers": {
    "subway": {
      "command": "npx",
      "args": ["-y", "@municode/subway@latest", "subway-mcp"]
    }
  }
}
```

**Cursor** (`.cursor/mcp.json` in the project root):
```json
{
  "mcpServers": {
    "subway": {
      "command": "npx",
      "args": ["-y", "@municode/subway@latest", "subway-mcp"]
    }
  }
}
```

### Fallback: CLI mode (no MCP)

If the MCP server is not configured and cannot be added, use the CLI directly:

```bash
# Scan project and auto-generate subway.json (no embed/narrate needed)
npx @municode/subway subway init

# Generate the viewer HTML
npx @municode/subway subway serve

# Open the viewer
open subway.html   # macOS
xdg-open subway.html  # Linux
start subway.html  # Windows
```

The `subway init` command auto-analyzes the codebase using tree-sitter AST
parsing and generates a complete `subway.json`. The `subway serve` command
generates the viewer HTML from it. This CLI path skips the interactive
MCP-based workflow entirely.

**Note:** When used as an LLM skill, the `--embed` and `--narrate` CLI flags
are unnecessary — the LLM itself provides semantic understanding (embed
replacement) and generates all descriptions, roles, and flow narratives
(narrate replacement).

Once installed and configured, proceed to the workflow below.

## Workflow Decision Tree

```
Is the Subway MCP server configured?

  ├─ YES → Use the MCP workflow below
  │
  └─ NO  → Run "npx @municode/subway subway init" then "npx @municode/subway subway serve"

Is there already a subway.json?

  ├─ YES → Go to "Serve an Existing Map" below
  │
  └─ NO  → Go to "Generate a New Map" below
```

## Generate a New Map

When no `subway.json` exists, build the map interactively using the MCP build
tools in this order:

### 0. Detect Environment First

**Before initializing the map, determine the project environment.** Read the
project root and check for framework markers (see the Environment Detection
table above). This determines what files matter and what to ignore.

### 1. Initialize the Map Session

Call `subway_init_map` to start a new building session. Pass the project root
directory (use `.` for the current workspace).

```
subway_init_map(root: ".")
```

This scans the project, lists top-level directories, detected languages, and
entry-point files. It creates an in-memory session.

### 2. Explore the Codebase

Use `subway_read_dir` to explore directories and `subway_read_file` to
read source files. **Apply the environment-specific and universal filtering
rules above** — skip dot-files, system files, build artifacts, framework
intrinsics, dependencies, and generated code.

Focus on the project's own source code, adapted to the detected environment:

- Entry points (`index.ts`, `App.tsx`, `main.dart`, `main.swift`, `MainActivity.kt`)
- Service modules (auth, api, db, networking)
- Feature screens / pages / views
- Component trees / widget hierarchies
- Route definitions / navigation graphs
- State management / ViewModels / Blocs / Stores
- Business logic / use cases / interactors
- Error handling / fallback screens

Limit the scan: target the most important 20–40 files. Every station needs at
least one file. Every synapse needs a meaningful condition.

### 3. Define Worlds (Domain Groups)

Use `subway_add_world` to define logical domains. Choose 3–7 worlds that
partition the codebase cleanly:

```
subway_add_world(id: "auth", name: "Authentication")
subway_add_world(id: "checkout", name: "Checkout Flow")
subway_add_world(id: "core", name: "Core Infrastructure")
```

World IDs become the visual grouping color. Each gets an auto-assigned color
from the Subway palette.

### 4. Add Stations (Components / Modules / Services)

Use `subway_add_station` for each significant component. Assign a **role**
and a **world**:

| Role | Meaning | Example |
|------|---------|---------|
| `start` | Entry point | App.tsx, index.ts, main() |
| `hub` | Dispatcher / router | Router, StateManager, API client |
| `checkpoint` | Intermediate state | FormScreen, Validator, Parser |
| `importance` | Critical component | PaymentProcessor, AuthGuard |
| `terminal` | End state | SuccessScreen, ErrorFallback, TimeoutScreen |

For `terminal` stations, also set `terminalType`: `success`, `failure`, or
`partial`.

Every station must have:
- `id` — kebab-case unique identifier
- `label` — human-readable name
- `world` — the domain it belongs to
- `role` — its role in the flow
- `files` — at least one source file path. **Only include project-owned source files** (no dot-files, no build artifacts, no generated code, no lock files, no dependencies).
- `description` — 1–2 sentences about what it does

Optionally set `influence` and `dependency` weights (0–1) to reflect the
station's importance and risk.

### 5. Connect Stations with Synapses

Use `subway_add_synapse` to define transitions. Every synapse has:

- `from` / `to` — station IDs
- `conditionDescription` — human-readable explanation
- `conditionType` — one of: `always`, `api_response`, `user_role`,
  `device_state`, `config_flag`, `data_value`
- `direction` — `forward`, `back`, or `both`
- `isCritical` — whether this is a critical path
- `strength` — 0–1 synaptic weight

Example:
```
subway_add_synapse(
  from: "login_screen",
  to: "auth_service",
  conditionDescription: "User taps 'Sign In' with valid credentials",
  conditionType: "user_role",
  direction: "forward",
  isCritical: true,
  strength: 0.9
)
```

Aim for 1.5–2 synapses per station on average.

### 6. Define Lines (End-to-End Flows)

Use `subway_add_line` to define complete user flows. Each line tells a story
by tracing stations in order:

```
subway_add_line(
  id: "line_checkout_happy",
  name: "Happy Checkout Flow",
  path: ["cart", "review", "payment", "confirmation"],
  outcome: "success"
)
```

Also define failure lines (outcome: `failure` or `partial`) to capture error
paths.

### 7. Review and Save

Check progress with `subway_status`. Call `subway_list_stations` and
`subway_list_lines` to verify completeness. **Re-verify the file filtering rule** —
no station should reference a dot-file, system file, build artifact, lock file,
or dependency. When satisfied, save:

```
subway_save_map()
```

This writes `subway.json` to the project root.

### 8. Generate the Viewer

```
subway_serve()
```

This generates a self-contained HTML viewer (`subway.html`) alongside the
JSON. Open the HTML file in any browser — no server, no build step, no npm
install needed.

## Serve an Existing Map

When `subway.json` already exists, generate and open the viewer:

1. Call `subway_serve` (no arguments needed; it uses the in-memory session
   if one exists, otherwise it reads from disk)

The tool saves the schema to `subway.json`, generates a self-contained
`subway.html` viewer using D3 force layout, and returns the file paths.
Open the HTML file in a browser.

## Explore an Existing Map (Read Operations)

After a map is loaded, use the MCP read tools to answer questions:

- `subway_search("error handling")` — synaptic search with spreading
  activation
- `subway_station("login")` — full details of a station
- `subway_path(from: "login", to: "confirmation")` — find a path with
  conditions
- `subway_impact("payment_service")` — blast radius analysis
- `subway_conditions("checkout")` — all conditions to reach a station
- `subway_onboard("frontend")` — guided learning path for a role
- `subway_line("checkout")` — describe an end-to-end flow
- `subway_busrisk()` — find single-author bottlenecks
- `subway_ask("how does auth work?")` — natural language Q&A

## Resources

### references/
- `tools.md` — Complete catalog of all 23 Subway MCP tools with parameters
  and descriptions
- `schema.md` — The subway.json v3.0 schema specification with all types,
  roles, and weight semantics

Load these reference files when detailed tool signatures or schema field
definitions are needed during map building or exploration.
