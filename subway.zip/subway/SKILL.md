---
name: subway
description: This skill should be used when the user requests creation, modification, exploration, or querying of a Subway codebase map. It teaches AI agents to parse repository structures into visualizable codebase nervous systems, compute synaptic weights, execute spreading activation searches, conduct impact analysis, and generate subway.json files.
---

# Subway

## Overview

This skill teaches agents to model, explore, and analyze any software repository as a **nervous system** (a Subway map). It outlines the foundational mapping components (Worlds, Stations, Synapses, Lines, and Weights), the 5-phase analysis pipeline, and the mathematical and operational procedures for executing semantic Synaptic Searches and Impact Analyses.

---

## 1. Core Architecture & Concepts

To represent a codebase as a Subway map, map every logical component and pathway to one of the following core concepts:

### WORLD (Logical Domain)
Group cohesive code modules into a unified World. Each World represents a high-level subsystem (e.g., `AUTH`, `CART`, `PAYMENT`, `CORE`) and is characterized by a distinct hex color and semantic definition.

### STATION (State Node)
Map every state, controller, view, use case, or repository component to a Station node. Assign one of these core functional roles to each Station:
- `start`: The title screen or absolute entry point.
- `hub`: A primary router or dispatcher.
- `checkpoint`: A saved intermediate state.
- `importance`: A critical high-risk component (e.g., transaction processors).
- `terminal`: A leaf state with no forward outlets. Set its `terminalType` to `success` (✓), `failure` (✗), or `partial` (⚠).

### SYNAPSE (Transition Path)
Connect stations via Synapses representing conditional logic flow. Each Synapse defines:
- A condition description (e.g., "Google sign-in fails").
- A condition trigger category (e.g., `api_response`, `user_role`, `config_flag`, `data_value`).
- A precise conditional check expression.
- A flow direction (`forward`, `back`, or `both`).
- A synapse weight/strength ($0.0 - 1.0$) based on dependency cohesion.

### LINE (End-to-End Story)
Map continuous user and system execution journeys (e.g., "Express checkout success run") as Lines, connecting multiple Stations and conditional Synapses from entry points to terminal nodes.

### SYNAPTIC WEIGHTS
Compute four dimensional weight metrics (scaled $0.0 - 1.0$) for every Station node:
- **Influence**: Ratio of downstream nodes importing/depending on this node.
- **Dependency**: The inverse test coverage safety ratio (highly imported + poorly tested = high dependency).
- **Churn**: Commit frequency per file (hotspots).
- **Centrality**: Graph betweenness centrality (frequency of traversal).

---

## 2. The 5-Phase Analysis Pipeline

To analyze a repository and generate or update a Subway map, execute the following five pipeline phases sequentially.

```
+---------------+      +----------------+      +-----------------+      +----------------+      +--------------+
| Phase 1: TRACE| ---> |Phase 2: WEIGHT | ---> |Phase 3: CLUSTER | ---> |Phase 4: EMBED  | ---> |Phase 5: EMIT |
+---------------+      +----------------+      +-----------------+      +----------------+      +--------------+
```

### Phase 1: Trace
1. Parse the application's root structures to detect entry point files (e.g., `main.ts`, `AppDelegate.swift`, `index.js`).
2. Follow routing modules, navigation controllers, intent dispatchers, and function calls to map connection paths.
3. Parse control structures (`if`, `switch`, `guard`, `catch`) to extract conditional logic and assign terminal leaf statuses.

### Phase 2: Weight
1. Traverse Git history to extract commit counts, author distributions, and modify frequencies per source file (churn and bus factors).
2. Construct the import dependency graph to identify centrality (betweenness) and structural coupling (influence).
3. Read coverage reports to weigh node fragility metrics relative to test density.

### Phase 3: Cluster
1. Apply community detection algorithms (e.g., Louvain clustering) on the dependency graph to isolate cohesive Worlds.
2. Group files and assign specific roles (`hub`, `checkpoint`, `importance`, `terminal`) to Station nodes.
3. Format user-friendly narration descriptions for Worlds, Stations, and Synaptic conditions.

### Phase 4: Embed
1. Generate high-quality semantic vector embeddings for each Station node based on its labels, file descriptions, and domain context.
2. Store the resulting float arrays inside the final map output for semantic searches.

### Phase 5: Emit
1. Compile all compiled metadata, structures, weights, and vectors into a single, fully-compliant `subway.json` file.
2. Ensure the output matches the specification defined in [schema.md](file:///Users/vince/.gemini/config/skills/subway/references/schema.md).

---

## 3. Querying & Operations

To interrogate or manipulate a Subway map, execute the following operational workflows:

### Synaptic Search
To simulate or execute text searches across the codebase nervous system:
1. Generate the search query's vector embedding.
2. Calculate the cosine similarity against all Station embeddings.
3. Propagate activation energy down connected synapses using the spreading activation algorithm.
4. Scale visual rendering weights (size, opacity, glow) based on final energy.
5. Refer to [algorithm.md](file:///Users/vince/.gemini/config/skills/subway/references/algorithm.md) for full algorithmic equations and pseudocode.

### Impact Analysis
To evaluate the downstream risks of refactoring or editing code:
1. Select the target Station node to analyze.
2. Traverse outgoing forward synapses recursively.
3. Mark immediate adjacent nodes as Red (Direct Impact).
4. Mark subsequent two-hop reachable nodes as Orange (Indirect Impact).
5. Output the list of impacted files, testing requirements, and affected code areas.

### Role-Based Onboarding
To onboard a new developer into a specific engineering role:
1. Identify the targeted World domain.
2. Extract the critical execution Lines relevant to that domain.
3. Generate a sequential checklist showing stations to inspect, matching files to read, and transition conditions to analyze.

---

## 4. Resources Reference

Consult these modular reference specifications before performing operations:

- **JSON Schema & Examples**: See [schema.md](file:///Users/vince/.gemini/config/skills/subway/references/schema.md) for the universal file schema.
- **Search Logic Specifications**: See [algorithm.md](file:///Users/vince/.gemini/config/skills/subway/references/algorithm.md) for Spreading Activation equations.
- **Command & Tool Documentation**: See [commands.md](file:///Users/vince/.gemini/config/skills/subway/references/commands.md) for CLI commands and MCP API specs.
