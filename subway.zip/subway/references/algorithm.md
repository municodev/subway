# The Synaptic Search Algorithm

Synaptic Search implements a cognitive-inspired spreading activation model on the codebase dependency graph. Instead of returning a flat list of matching filenames, it simulates brain activation propagating through neural pathways (synapses).

## Mathematical & Neuroscientific Principles

### 1. Semantic Initialization
Given a text search query $q$, the system converts it into a high-dimensional vector $\vec{q}$ using a vector embedding model (e.g. `text-embedding-3-small`). The similarity score between the query and a station $S_i$ is determined via Cosine Similarity:

$$\text{Sim}(q, S_i) = \frac{\vec{q} \cdot \vec{e}_i}{\|\vec{q}\| \|\vec{e}_i\|}$$

The station with the highest similarity is identified as the **primary activation node**.

### 2. Spreading Activation propagation
From the primary node, "energy" is pushed down connected synapses. The amount of activation energy $A$ that reaches a neighboring node $S_j$ from $S_i$ is computed as:

$$A(S_j) = A(S_i) \times \text{Strength}(Syn_{ij}) \times \text{DecayFactor}$$

Where:
- $\text{Strength}(Syn_{ij})$ (float $0.0 - 1.0$) is the synaptic weight/strength of the link.
- $\text{DecayFactor}$ (float $0.0 - 1.0$, default `0.5`) is the exponential decay per jump to limit propagation.
- If a node is reached via multiple paths, its activation is the maximum of all incoming activations: $A(S_j) = \max_p(A_p(S_j))$.
- Propagation stops when $A(S_j) \le \text{Threshold}$ (default `0.1`).

### 3. Visual Activation Rendering
Activated nodes are rendered with visual attributes tied directly to their activation values:

$$\text{NodeSize} = \text{BaseSize} \times (1 + A(S))$$
$$\text{Opacity} = 0.2 + (A(S) \times 0.8)$$
$$\text{GlowRadius} = A(S) \times \text{MaxGlow}$$

Unactivated nodes ($A(S) = 0$) do not vanish; instead, they fade to a low background opacity ($\text{Opacity} = 0.05$), creating a "constellation" highlighting the active network pathways in context.

---

## Algorithm Pseudocode

```python
def synaptic_search(query_text, graph, threshold=0.1, decay_factor=0.5):
    # Step 1: Generate query embedding
    query_vector = get_embedding(query_text)
    
    # Step 2: Compute initial similarity for all stations
    primary_node = None
    max_sim = -1.0
    
    for station in graph.stations:
        sim = cosine_similarity(query_vector, station.embedding)
        station.activation = 0.0
        if sim > max_sim:
            max_sim = sim
            primary_node = station
            
    if not primary_node:
        return []
        
    # Initialize primary node activation
    primary_node.activation = max_sim
    
    # Step 3: Spread activation using BFS-like queue
    queue = [primary_node]
    visited = set()
    
    while queue:
        current = queue.pop(0)
        visited.add(current.id)
        
        # Traverse synapses
        for synapse in graph.out_synapses(from_node=current.id):
            neighbor = graph.get_station(synapse.to)
            
            # Calculate propagated energy
            propagated_energy = current.activation * synapse.strength * decay_factor
            
            # Update only if it exceeds threshold and is larger than previous activation
            if propagated_energy > threshold:
                if propagated_energy > neighbor.activation:
                    neighbor.activation = propagated_energy
                    if neighbor.id not in visited:
                        queue.append(neighbor)
                        
    # Step 4: Return list of activated stations sorted by energy
    activated_stations = [s for s in graph.stations if s.activation > 0.0]
    return sorted(activated_stations, key=lambda s: s.activation, reverse=True)
```
