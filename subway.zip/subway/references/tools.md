# Subway MCP Tools Reference

All 23 tools available through the Subway MCP server.

## Build Tools (14) — Create Maps Interactively

### subway_init_map
Initialize a new map building session.
- **Parameters**: `root` (optional, default `.`), `name` (optional, basename of root)
- **Returns**: Project scan — directories, files, languages, entry points

### subway_read_file
Read source file contents.
- **Parameters**: `path` (string, relative to project root)
- **Returns**: File content with line breaks preserved

### subway_read_dir
List directory contents.
- **Parameters**: `path` (optional, default project root)
- **Returns**: Directories and files with sizes, sorted directories-first

### subway_add_world
Add a domain/world to the map.
- **Parameters**: `id` (string), `name` (string), `color` (optional hex), `description` (optional)
- **Returns**: Created world with stations array

### subway_add_station
Add a station (component/service/module/screen) to the map.
- **Parameters**:
  - `id` (string) — unique identifier
  - `label` (string) — human-readable name
  - `world` (string) — parent world ID
  - `role` (enum) — `start`, `hub`, `checkpoint`, `importance`, `terminal`
  - `terminalType` (optional enum) — `success`, `failure`, `partial` (only when role is `terminal`)
  - `files` (optional string[]) — source file paths
  - `description` (optional string)
  - `authors` (optional string[])
  - `influence` (optional number 0–1)
  - `dependency` (optional number 0–1)
- **Returns**: Created station with all computed fields

### subway_update_station
Update fields of an existing station.
- **Parameters**: `id` (string) + any subset of add fields
- **Returns**: Updated station or null

### subway_remove_station
Remove a station and all its synapses. Cleans up world memberships and line paths.
- **Parameters**: `id` (string)
- **Returns**: Success/failure message

### subway_add_synapse
Add a transition between two stations.
- **Parameters**:
  - `from` (string) — source station ID
  - `to` (string) — destination station ID
  - `conditionDescription` (string)
  - `conditionType` (enum) — `always`, `api_response`, `user_role`, `device_state`, `config_flag`, `data_value`
  - `conditionValue` (optional string) — actual condition expression
  - `direction` (optional enum) — `forward`, `back`, `both` (default: `forward`)
  - `isCritical` (optional boolean)
  - `strength` (optional number 0–1, default: 0.5)
- **Returns**: Created synapse

### subway_remove_synapse
Remove a synapse between two stations.
- **Parameters**: `from` (string), `to` (string)
- **Returns**: Success/failure message

### subway_add_line
Add a complete end-to-end flow.
- **Parameters**:
  - `id` (string)
  - `name` (string)
  - `path` (string[]) — ordered station IDs (min 2)
  - `world` (optional string)
  - `color` (optional hex, default: `#4cc9f0`)
  - `conditions` (optional string[]) — summary conditions
  - `outcome` (optional enum) — `success`, `failure`, `partial` (default: `success`)
- **Returns**: Created line

### subway_save_map
Persist the in-memory map to `subway.json`.
- **Parameters**: `output` (optional, default: `subway.json` in project root)
- **Returns**: File path, station/synapse/line counts

### subway_status
Show current session status — counts, breakdown by world and role.
- **Parameters**: none
- **Returns**: Station/synapse/world/line counts, role distribution

### subway_list_stations
List all stations, optionally filtered by world.
- **Parameters**: `world` (optional string)
- **Returns**: Station table with role, world, files, description

### subway_list_lines
List all lines with their paths, conditions, and outcomes.
- **Parameters**: none
- **Returns**: Line table with path traversal visualization

### subway_list_worlds
List all worlds with their station counts.
- **Parameters**: none
- **Returns**: World table with stations and descriptions

### subway_scan
Run a deeper codebase scan after the session is started.
- **Parameters**: none
- **Returns**: Updated scan results with file list, entry points, framework hints

### subway_serve
Generate the viewer HTML from the current map and return the file path.
- **Parameters**: none
- **Returns**: Paths to `subway.json` and `subway.html`, HTML file size

## Query Tools (5) — Inspect In-Memory Build Session

These tools query the CURRENT in-memory session (not the saved file).

### subway_query_search
Search the in-memory map for stations matching a query.
- **Parameters**: `query` (string), `limit` (optional number, default: 10)
- **Returns**: Matching stations with scores

### subway_query_station
Get detailed info about a station in the in-memory map. Accepts ID or label.
- **Parameters**: `id` (string)
- **Returns**: Station details

### subway_query_path
Find a path between two stations in the in-memory map.
- **Parameters**: `from` (string), `to` (string)
- **Returns**: Step-by-step path with conditions

### subway_query_impact
Analyze impact of changing a station in the in-memory map.
- **Parameters**: `id` (string)
- **Returns**: Affected stations, impact score

### subway_query_conditions
Show all conditions to reach a station in the in-memory map.
- **Parameters**: `id` (string)
- **Returns**: Incoming synapse conditions + line conditions

## Read Tools (9) — Explore Loaded Maps

These tools query the loaded `subway.json` file.

### subway_search
Synaptic search with spreading activation. Supports technical, functional,
and symptomatic queries in any language.
- **Parameters**: `query` (string), `mode` (optional `semantic`|`keyword`, default: `keyword`), `limit` (optional)
- **Returns**: Activated stations with scores and related stations

### subway_station
Get detailed information about a specific station.
- **Parameters**: `id` (string) — ID or label
- **Returns**: Role, weights, files, authors, incoming/outgoing synapses

### subway_path
Find the path between two stations through the synapse graph.
- **Parameters**: `from` (string), `to` (string)
- **Returns**: Step-by-step transitions with conditions

### subway_impact
Analyze impact/blast radius of changing a station.
- **Parameters**: `id` (string)
- **Returns**: Direct dependents, 2-hop impact, composite score

### subway_conditions
Show all conditions to reach a station.
- **Parameters**: `id` (string)
- **Returns**: Incoming synapse chain + lines passing through

### subway_onboard
Generate a guided onboarding path for a development role.
- **Parameters**: `role` (string) — `frontend`, `backend`, `fullstack`, `mobile`, `devops`, `qa`, `data`
- **Returns**: Entry points, critical stations, end states, learning order

### subway_line
Describe a complete end-to-end user flow by line name.
- **Parameters**: `name` (string) — full or partial
- **Returns**: Full path, outcome, conditions

### subway_busrisk
Identify single-author bottlenecks.
- **Parameters**: `limit` (optional number, default: 10)
- **Returns**: Stations sorted by influence × centrality, author count

### subway_ask
Answer natural language questions about the codebase.
- **Parameters**: `question` (string) — any language
- **Returns**: Contextual answer with station details and suggestions
