# Subway JSON Schema & Sample Structure (`subway.json`)

To ensure interoperability between analysis tools, visualizers, CLI commands, and AI agents, all Subway maps must strictly adhere to the `subway.json` format.

## Format Specifications

A valid `subway.json` file consists of four primary root blocks: `meta`, `worlds`, `stations`, `synapses`, and `lines`.

### 1. `meta` Block
Metadata regarding the codebase analysis.
- `project` (string): Name of the analyzed project.
- `version` (string): Subway specification version (e.g., `"3.0"`).
- `generated` (string): ISO 8601 timestamp of when the map was generated.
- `entryPoint` (string): The ID of the absolute entry point station (`start` station role).
- `totalStations` (integer): Total number of stations mapped.
- `totalSynapses` (integer): Total number of transitions mapped.
- `totalLines` (integer): Total number of complete runs/flow paths mapped.
- `totalWorlds` (integer): Total number of logical domains (worlds) identified.
- `languages` (array of strings): Code languages detected (e.g., `["typescript", "javascript"]`).
- `embeddings_model` (string): Model used for generating semantic search vectors.

### 2. `worlds` Block
An array of logical domains. Each world contains:
- `id` (string): Unique identifier for the world.
- `name` (string): User-friendly display name.
- `color` (string): Dominant hex color code establishing its visual identity.
- `description` (string): Brief semantic explanation of the domain's purpose.
- `stations` (array of strings): IDs of stations belonging to this world.

### 3. `stations` Block
An array of states/components in the system nervous system. Each station contains:
- `id` (string): Unique identifier for the station.
- `label` (string): Technical or functional class/service/view name (e.g., `"PaymentService"`).
- `world` (string): The ID of the world this station belongs to.
- `role` (string): The station's structural role:
  - `"start"`: Main entry point of the app or flow.
  - `"hub"`: Primary router or dispatcher.
  - `"checkpoint"`: Saved intermediate state.
  - `"importance"`: Highly critical / high-impact core component.
  - `"terminal"`: Leaf node with no forward outlets.
- `terminalType` (string or null): If role is `"terminal"`, must be `"success"`, `"failure"`, or `"partial"`. Otherwise `null`.
- `files` (array of strings): List of physical source files corresponding to this station.
- `description` (string): LLM-generated semantic description of what this station represents and does.
- `weight` (object): Normalized float values between `0.0` and `1.0`:
  - `influence`: How many other stations depend on this node.
  - `dependency`: Ratio of external imports vs. test coverage (higher = high dependency + poorly tested = risk).
  - `churn`: Frequency of code modifications over time (from git commit history).
  - `centrality`: Structural betweenness in the graph network.
- `authors` (array of strings): Primary git authors of the files.
- `lastModified` (string): ISO 8601 timestamp of last commit touching these files.
- `commitCount` (integer): Number of git commits touching these files.
- `embedding` (array of floats): Semantic search vector representation of the station.

### 4. `synapses` Block
An array of conditional transitions between stations. Each synapse contains:
- `from` (string): Starting station ID.
- `to` (string): Target station ID.
- `condition` (object): The logic governing the transition:
  - `description` (string): Human-readable explanation of when this transition happens.
  - `type` (string): Category of trigger (`"api_response"`, `"user_role"`, `"device_state"`, `"config_flag"`, `"data_value"`, `"always"`).
  - `value` (string): Precise check expression (e.g. `"user.action === 'CHECKOUT'"`).
- `direction` (string): Transition path flow (`"forward"`, `"back"`, `"both"`).
- `isCritical` (boolean): `true` if this synapse lies on a high-risk checkout or critical execution path.
- `strength` (float): Normalized weight representing probability or strength of association (0.0 to 1.0).

### 5. `lines` Block
An array of end-to-end runs/flown paths mapping concrete onboarding stories. Each line contains:
- `id` (string): Unique identifier for the line.
- `name` (string): Human-readable story title.
- `world` (string): Primary world domain of this flow.
- `color` (string): Display color for tracing this path line on the map.
- `path` (array of strings): Ordered list of station IDs traversed from starting node to terminal node.
- `conditions` (array of strings): Key check criteria verified along the path.
- `outcome` (string): Must be `"success"`, `"failure"`, or `"partial"`.

---

## Golden Sample `subway.json`

Below is a reference implementation of a generic E-Commerce checkout map matching this schema:

```json
{
  "meta": {
    "project": "E-Commerce System",
    "version": "3.0",
    "generated": "2026-05-22T10:00:00Z",
    "entryPoint": "station_landing_page",
    "totalStations": 42,
    "totalSynapses": 118,
    "totalLines": 14,
    "totalWorlds": 6,
    "languages": ["typescript", "javascript"],
    "embeddings_model": "text-embedding-3-small"
  },
  "worlds": [
    {
      "id": "auth",
      "name": "Authentication",
      "color": "#f5a623",
      "description": "Gestisce identità e accesso. Entry point per tutti gli utenti dell'applicazione.",
      "stations": ["station_oauth", "station_login"]
    }
  ],
  "stations": [
    {
      "id": "station_login",
      "label": "PaymentService",
      "world": "auth",
      "role": "hub",
      "terminalType": null,
      "files": ["PaymentService.ts", "PaymentViewModel.ts"],
      "description": "Gestisce l'autenticazione degli utenti. Smista il flusso verso Dashboard, Billing o Admin in base al ruolo dell'utente.",
      "weight": {
        "influence": 0.91,
        "dependency": 0.43,
        "churn": 0.67,
        "centrality": 0.88
      },
      "authors": ["john.doe", "jane.smith"],
      "lastModified": "2026-04-10T14:22:00Z",
      "commitCount": 47,
      "embedding": [0.021, -0.143, 0.887]
    }
  ],
  "synapses": [
    {
      "from": "station_login",
      "to": "station_checkout_flow",
      "condition": {
        "description": "L'utente seleziona il checkout",
        "type": "data_value",
        "value": "user.action === 'CHECKOUT'"
      },
      "direction": "forward",
      "isCritical": true,
      "strength": 0.74
    }
  ],
  "lines": [
    {
      "id": "line_checkout_happy",
      "name": "Acquisto Prodotto — Happy Path",
      "world": "checkout",
      "color": "#4cc9f0",
      "path": [
        "station_landing_page",
        "station_oauth",
        "station_login",
        "station_checkout_flow",
        "station_payment_form",
        "station_invoice_generation",
        "station_checkout_success"
      ],
      "conditions": [
        "cart.total > 0",
        "user.isLoggedIn === true",
        "payment.status === 'SUCCESS'"
      ],
      "outcome": "success"
    }
  ]
}
```
