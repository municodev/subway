# CLI & MCP Tool Reference

This document catalogs the command-line interface (CLI) commands and Model Context Protocol (MCP) server tools exposed by the Subway system.

## Command-Line Interface (CLI)

All CLI commands are executed via `npx subway` in the project directory root.

| Command | Usage / Parameters | Description |
|---|---|---|
| `npx subway init` | `npx subway init [--ci] [--model=text-embedding-3-small]` | Triggers full AST parsing, git log extraction, clustering, embedding generation, and LLM narration. Produces the final `subway.json` file. |
| `npx subway serve` | `npx subway serve [--port=4242]` | Starts the local development and static viewer web server showing the visual interactive codebase map. |
| `npx subway play` | `npx subway play <world_id>` | Animates the pathways and transitions of a specific World logic domain directly in the terminal or viewer. |
| `npx subway impact` | `npx subway impact <station_id>` | Evaluates and prints the direct and indirect downstream impacts of modifying the given Station. |
| `npx subway search` | `npx subway search "<query_string>"` | Runs a synaptic search directly from the terminal, outputting the activated node list with activation values. |
| `npx subway onboard` | `npx subway onboard --role=<role>` | Generates a sequential tutorial walkthrough path for developers onboarding into a specific role (e.g. `frontend`, `backend`, `mobile`). |
| `npx subway diff` | `npx subway diff <commit_ish>` | Calculates and outputs structural differences between the current codebase graph and a previous Git commit. |

---

## MCP Server Tools

The Subway MCP server allows external AI agents (like Claude or Cursor) to query the codebase's nervous system directly.

### 1. `subway_ask(question: string)`
Asks a natural language question about the codebase. Returns a synthesized answer using the graph database context.

### 2. `subway_station(id: string)`
Fetches detailed semantic description, linked files, primary authors, weights (influence, dependency, churn, centrality), and entry/exit synapses of a specific station.

### 3. `subway_search(query: string)`
Executes the Spreading Activation Synaptic Search on the graph. Returns a list of activated stations sorted by energy score.

### 4. `subway_path(from: string, to: string)`
Calculates the shortest or most logical pathway between two stations, including transition conditions and intermediate nodes.

### 5. `subway_impact(id: string)`
Conducts impact analysis on a station. Returns lists of directly and indirectly impacted stations.

### 6. `subway_conditions(id: string)`
Returns the precise list of cumulative conditions (e.g. api responses, configurations, flags) that must be met to reach the given station from the entry point.

### 7. `subway_onboard(role: string)`
Returns a curated list of stations, source files, and conceptual milestones to guide a developer onboarding into the specified engineering role.

### 8. `subway_line(name: string)`
Walks through a complete end-to-end user/system execution line, explaining each step and conditional branch in detail.

### 9. `subway_busrisk()`
Analyzes git metadata across all stations. Returns stations with a high risk profile (e.g., single author nodes, or nodes with extremely high churn and centrality).
